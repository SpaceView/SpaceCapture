Contact Information
Questions?  Concerns?  Send any feedback for this tool to  tansheng@spacesoftwares.com

Release Notice:

settings are generally saved at C:\Users\Administrator\Documents\SpaceCapture, 
you can delete it if the old setting bothers you!

Language: English, Chinese; default to English;
Attension: Please don't store any of your important files under the folders created by the program!

version 1.09 - 20191020
Fix some display problem specifically on windows 10.
Remove the starting up Company LOGO. 

version 1.08 - 20190112
Fix some image processing problem.

version 1.07f - 20181116
Fix some bizarre display & saving problem such as flash on some windows versions.

version 1.07d - 20181003
Optimize the speed in capture
Watermark for big image removed
Fix the problem of the occasional sluggish response to mouse click

version 1.07c - 20180720
Fix the problem of sluggish button response on some old system.

version 1.07b - 20180714
Fix some compatibile problems for different windows versions. 
Allow opacity to be set by user.
Use system Docuements folder for saving temporary files, no administrator priviledge required anymore. 
Generally the folder name is C:\Users\Administrator\Documents\SpaceCapture

version 1.06 - 2018705
Fix text repeating edit command causing big box problem

version 1.05 - 2018704
Partial drawn rects inside image combined into the image with auto intersection
Drag borders are drawn to indicate dimension change support

version 1.04 -20180628
Immediate color update for text and drawing at the same time.
Selection redo and undo function added.

version 1.03 -20180626
Image editor drag box optimized.
Clipboard notice updated.

version 1.02 -20160620
Image editor function enhanced:
Create new default blank image or create image from clipboard;
Add new arrow drawing function and selected area drag and drop capabilities,
Text edit function added,
Art text edit function added,
Screen snapshot/capture enhanced:
Add dimension info in fixed area screen capture,
customizable line width in target selection
new capability to repeat the last area captured (capture the same area repeated with shortkey R);

version 1.01 -20160520
Button size and style updated;

Security Permissions Required
No special permissions required for the user.

Uninstalling
Delete the folder where you unzipped the files.

Disclaimer
This software application is provided to you "as is" with no representations, warranties or conditions of any kind.  You may use and distribute it at your own risk. SPACECAPTURE DISCLAIMS ALL WARRANTIES WHATSOEVER, EXPRESS, IMPLIED, WRITTEN, ORAL OR STATUTORY, INCLUDING WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NONINFRINGEMENT. Without limiting the generality of the foregoing, you acknowledge and agree that (a) the software application may exhibit errors, design flaws or other problems, possibly resulting in loss of data or damage to property; (b) it may not be possible to make the software application fully functional; and (c)SpaceCapture may, without notice or liability to you, cease to make available the current version and/or any future versions of the software application.  In no event should the code be used to support of ultra-hazardous activities, including but not limited to life support or blasting activities.  NEITHER SPACECAPTURE NOR ITS AFFILIATES OR AGENTS WILL BE LIABLE, UNDER BREACH OF CONTRACT OR ANY OTHER THEORY OF LIABILITY, FOR ANY DAMAGES WHATSOEVER ARISING FROM USE OF THE SOFTWARE APPLICATION, INCLUDING WITHOUT LIMITATION DIRECT, SPECIAL, INCIDENTAL, PUNITIVE, CONSEQUENTIAL OR OTHER DAMAGES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. You agree to indemnify and defend SpaceCapture against any and all claims arising from your use, modification or distribution of the code.
