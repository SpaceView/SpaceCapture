Release Notice:

Language: English, Chinese; default to English;
Attension:
1. Please don't store any of your important files under the folders created by the program!
2. If you don't see the frame when recording the video, please go to Setting->General-> check the "Display record frame"


version 1.01 - 20181003
Update, show capture frame by default

version 1.00 - 20180520

About SpaceSoftwares
SpaceSoftwares, a small team specialized in image, audio, and video technology and algorithm.
We target at providing first class tools for everyone, no matter in your work, or for your amusements.
For any problem, please don��t hesitate to contact us!
You can visit us at SpaceSoftwares.com, or email: SpaceSoftwares@hotmail.com.

Security Permissions Required
No special permissions required for the user.

Uninstalling
Delete the folder where you unzipped the files.

Contact Information
Questions?  Concerns?  Send any feedback for this tool to spaceSoftwares@hotmail.com.

Disclaimer
This software application is provided to you "as is" with no representations, warranties or conditions of any kind.  You may use and distribute it at your own risk. SPACECAPTURE DISCLAIMS ALL WARRANTIES WHATSOEVER, EXPRESS, IMPLIED, WRITTEN, ORAL OR STATUTORY, INCLUDING WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NONINFRINGEMENT. Without limiting the generality of the foregoing, you acknowledge and agree that (a) the software application may exhibit errors, design flaws or other problems, possibly resulting in loss of data or damage to property; (b) it may not be possible to make the software application fully functional; and (c)SpaceCapture may, without notice or liability to you, cease to make available the current version and/or any future versions of the software application.  In no event should the code be used to support of ultra-hazardous activities, including but not limited to life support or blasting activities.  NEITHER SPACECAPTURE NOR ITS AFFILIATES OR AGENTS WILL BE LIABLE, UNDER BREACH OF CONTRACT OR ANY OTHER THEORY OF LIABILITY, FOR ANY DAMAGES WHATSOEVER ARISING FROM USE OF THE SOFTWARE APPLICATION, INCLUDING WITHOUT LIMITATION DIRECT, SPECIAL, INCIDENTAL, PUNITIVE, CONSEQUENTIAL OR OTHER DAMAGES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. You agree to indemnify and defend SpaceCapture against any and all claims arising from your use, modification or distribution of the code.
